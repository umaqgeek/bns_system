
<div class="row" style="margin-top: 5%;">
    <div class="col-md-8 col-md-offset-2">

<!--        <p id="demo">Click the button to get your position.</p>-->
        <p>Here is your location.</p>

        <!--<button onclick="getLocation()">Try It</button>-->

        <div id="mapholder"></div>
        <article>

    </article>

        <script>
            var x = document.getElementById("demo");
            
            function loopLocation() {
                getLocation();
                setTimeout("loopLocation()", 2000);
            }

            getLocation();
//            loopLocation();
            function getLocation() {
                if (navigator.geolocation) {
                    var optn = {
                        enableHighAccuracy: true,
                        timeout           : Infinity,
                        maximumAge        : 0
                    };
//                    navigator.geolocation.getCurrentPosition(showPosition, showError);
                    var watchID = navigator.geolocation.watchPosition(showPosition, showError, optn);
                    
                } else {
                    x.innerHTML = "Geolocation is not supported by this browser.";
                }
            }

            function showPosition(position) {
//                var latlon = position.coords.latitude + "," + position.coords.longitude;
//
//                var img_url = "http://maps.googleapis.com/maps/api/staticmap?center="
//                        + latlon + "&zoom=16&size=800x600&sensor=false";
//                document.getElementById("mapholder").innerHTML = "<img src='" + img_url + "'>";

                var mapcanvas = document.createElement('div');
                mapcanvas.id = 'mapcontainer';
                mapcanvas.style.height = '400px';
                mapcanvas.style.width = '400px';

                document.querySelector('article').appendChild(mapcanvas);

                var coords = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
                
                $.post("<?=site_url('driver/saveDriverLocation'); ?>", {
                    latitud: position.coords.latitude,
                    longitud: position.coords.longitude
                }).done(function( data ) { });

                var options = {
                  zoom: 15,
                  center: coords,
                  mapTypeControl: false,
                  navigationControlOptions: {
                      style: google.maps.NavigationControlStyle.SMALL
                  },
                  mapTypeId: google.maps.MapTypeId.ROADMAP
                };
                var map = new google.maps.Map(document.getElementById("mapcontainer"), options);

                var marker = new google.maps.Marker({
                    position: coords,
                    map: map,
                    title:"You are here!"
                });
            }

            function showError(error) {
                switch (error.code) {
                    case error.PERMISSION_DENIED:
                        x.innerHTML = "User denied the request for Geolocation."
                        break;
                    case error.POSITION_UNAVAILABLE:
                        x.innerHTML = "Location information is unavailable."
                        break;
                    case error.TIMEOUT:
                        x.innerHTML = "The request to get user location timed out."
                        break;
                    case error.UNKNOWN_ERROR:
                        x.innerHTML = "An unknown error occurred."
                        break;
                }
            }
        </script>

    </div>
</div>